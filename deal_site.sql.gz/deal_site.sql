-- phpMyAdmin SQL Dump
-- version 3.3.2deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 06, 2011 at 08:44 PM
-- Server version: 5.1.41
-- PHP Version: 5.3.2-1ubuntu4.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `deal_site`
--

-- --------------------------------------------------------

--
-- Table structure for table `companies`
--

CREATE TABLE IF NOT EXISTS `companies` (
  `company_id` int(12) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(128) NOT NULL,
  `company_algo_rank` tinyint(3) NOT NULL,
  `company_about` text NOT NULL,
  `company_address` varchar(256) NOT NULL,
  `company_thumbs_up` int(9) NOT NULL,
  `company_thumbs_down` int(9) NOT NULL,
  PRIMARY KEY (`company_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COMMENT='Companies Table' AUTO_INCREMENT=3 ;

--
-- Dumping data for table `companies`
--

INSERT INTO `companies` (`company_id`, `company_name`, `company_algo_rank`, `company_about`, `company_address`, `company_thumbs_up`, `company_thumbs_down`) VALUES
(1, 'Einstein Bagel Company', 0, 'Einstein makes literally the best bagels in the world man.', '', 239, 9),
(2, 'Lime XS', 0, 'Lime XS has awesome margaritas and a really good taco Tuesday', '', 9898, 2);

-- --------------------------------------------------------

--
-- Table structure for table `deals`
--

CREATE TABLE IF NOT EXISTS `deals` (
  `deal_id` int(18) NOT NULL AUTO_INCREMENT,
  `deal_poster_id` int(12) NOT NULL,
  `company_id` int(12) NOT NULL,
  `deal_title` varchar(512) NOT NULL,
  `deal_price` decimal(10,2) NOT NULL,
  `deal_post_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deal_start_date` datetime NOT NULL,
  `deal_end_date` datetime NOT NULL,
  `deal_text` text NOT NULL,
  `deal_latitude` decimal(12,9) NOT NULL,
  `deal_longitude` decimal(12,9) NOT NULL,
  `deal_photo` varchar(1024) NOT NULL,
  `deal_tags` varchar(512) NOT NULL,
  `deal_views` int(18) NOT NULL,
  `deal_thumbs_up` int(9) NOT NULL,
  `deal_thumbs_down` int(9) NOT NULL,
  `deal_verified` tinyint(1) NOT NULL DEFAULT '0',
  `algo_ranking` tinyint(3) NOT NULL DEFAULT '0',
  `thanks_count` int(9) NOT NULL,
  `deal_active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`deal_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COMMENT='Deals table' AUTO_INCREMENT=3 ;

--
-- Dumping data for table `deals`
--

INSERT INTO `deals` (`deal_id`, `deal_poster_id`, `company_id`, `deal_title`, `deal_price`, `deal_post_date`, `deal_start_date`, `deal_end_date`, `deal_text`, `deal_latitude`, `deal_longitude`, `deal_photo`, `deal_tags`, `deal_views`, `deal_thumbs_up`, `deal_thumbs_down`, `deal_verified`, `algo_ranking`, `thanks_count`, `deal_active`) VALUES
(1, 20392, 2, 'Margaritas At Lime XS', 3.00, '2011-11-21 20:51:57', '0000-00-00 00:00:00', '2011-11-24 00:00:00', '<script>\r\nfor (i = 0; i < 50; i++) {\r\n  document.write(''get a dank marg here. '');\r\n}\r\n</script>', 39.725409000, -104.977867000, '', '1,2,3', 343, 878, 23, 1, 23, 2398, 1),
(2, 20392, 1, 'Bagel and Schmear at Einstein''s Bagel Company', 1.00, '2011-12-01 19:03:42', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '<script>\r\nfor (i = 0; i < 10; i++){\r\ndocument.write(''I love bagels yum. '');\r\n}\r\n</script>', 0.000000000, 0.000000000, '', '4,5', 0, 0, 0, 1, 72, 23, 1);

-- --------------------------------------------------------

--
-- Table structure for table `deal_comments`
--

CREATE TABLE IF NOT EXISTS `deal_comments` (
  `comment_id` int(18) NOT NULL AUTO_INCREMENT,
  `comment_deal_id` int(18) NOT NULL,
  `comment_poster_id` int(9) NOT NULL,
  `comment_title` varchar(512) NOT NULL,
  `comment_text` text NOT NULL,
  `comment_thumbs_up` int(9) NOT NULL,
  `comment_thumbs_down` int(9) NOT NULL,
  `comment_thanks_count` int(9) NOT NULL DEFAULT '0',
  `comment_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `algo_rank` tinyint(3) NOT NULL DEFAULT '0',
  `comment_active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`comment_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COMMENT='Deal comments table' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `deal_comments`
--

INSERT INTO `deal_comments` (`comment_id`, `comment_deal_id`, `comment_poster_id`, `comment_title`, `comment_text`, `comment_thumbs_up`, `comment_thumbs_down`, `comment_thanks_count`, `comment_date`, `algo_rank`, `comment_active`) VALUES
(1, 1, 9898, 'hello world', 'that is a sweet deal', 2837, 88, 9832, '2011-11-22 03:04:39', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `deal_tags`
--

CREATE TABLE IF NOT EXISTS `deal_tags` (
  `tag_id` int(9) NOT NULL AUTO_INCREMENT,
  `tag_text` varchar(32) NOT NULL,
  PRIMARY KEY (`tag_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COMMENT='Deal Tags Table' AUTO_INCREMENT=6 ;

--
-- Dumping data for table `deal_tags`
--

INSERT INTO `deal_tags` (`tag_id`, `tag_text`) VALUES
(1, 'alcohol'),
(2, 'food'),
(3, 'bar'),
(4, 'breakfast'),
(5, 'coffee');

-- --------------------------------------------------------

--
-- Table structure for table `ipgeoloc`
--

CREATE TABLE IF NOT EXISTS `ipgeoloc` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(15) NOT NULL,
  `city` varchar(128) NOT NULL,
  `state` char(2) NOT NULL,
  `zip_code` int(5) NOT NULL,
  `latitude` decimal(12,9) NOT NULL,
  `longitude` decimal(12,9) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COMMENT='IP Geolocation Table' AUTO_INCREMENT=3 ;

--
-- Dumping data for table `ipgeoloc`
--

INSERT INTO `ipgeoloc` (`id`, `ip_address`, `city`, `state`, `zip_code`, `latitude`, `longitude`) VALUES
(1, '75.196.170.230', 'Vallejo', 'CA', 94590, 38.146437585, -122.325382233),
(2, '174.51.121.32', 'Denver', 'CO', 80203, 39.739193000, -104.980219000);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(12) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(56) NOT NULL,
  `password` varchar(24) NOT NULL,
  `last_login` datetime NOT NULL,
  `creation_date` datetime NOT NULL,
  `ip_address` varchar(15) NOT NULL,
  `location` varchar(128) NOT NULL,
  `email_address` varchar(512) NOT NULL,
  `cell_carrier` varchar(56) NOT NULL,
  `cell_number` varchar(11) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COMMENT='user table' AUTO_INCREMENT=20393 ;

--
-- Dumping data for table `users`
--

